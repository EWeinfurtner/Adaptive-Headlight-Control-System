#include "arduino_secrets.h"

#include <Wire.h>                          // I2C communication for IMU and display-related peripherals
#include "Arduino_BMI270_BMM150.h"        // BMI270 IMU library used on the GIGA Display Shield
#include <Adafruit_NeoPixel.h>             // WS2812 / NeoPixel LED control library
#include "Arduino_H7_Video.h"             // Video driver for the Arduino GIGA Display Shield
#include "Arduino_GigaDisplay_GFX.h"      // Graphics library for drawing on the GIGA display

/* =========================================================
   ADAPTIVE MOTORCYCLE HEADLIGHT PROTOTYPE
   REVIEWED + COMMENTED VERSION

   Notes:
   - Functional behaviour intentionally preserved.
   - User-tuned parameters intentionally preserved.
   - Code has been reformatted and documented for clarity.
   ========================================================= */

/* =========================================================
   TYPE DEFINITIONS
   ========================================================= */
enum SwitchState { SW_OFF, SW_I, SW_II };                      // Raw 3-position switch states
enum BeamMode    { BEAM_ALL_OFF, BEAM_LOW_ONLY, BEAM_LOW_AND_HIGH }; // Lighting modes derived from switch state

enum AxisSel { AXIS_X, AXIS_Y, AXIS_Z };                      // Axis selector for coordinate mapping
enum ImuMode { MODE_ACC_ONLY, MODE_COMP, MODE_MADGWICK };     // Available IMU estimation modes

/* =========================================================
   USER CONFIGURATION
   ========================================================= */

// ---------------------- NeoPixel Hardware ----------------------
static const uint16_t NUM_LEDS  = 241;                        // Total number of LEDs in the matrix
static const uint8_t  DATA_PIN  = 25;                         // Data output pin for the WS2812 matrix
static const uint8_t  GLOBAL_STRIP_BRIGHTNESS = 255;          // Global strip brightness fixed at full scale

// ---------------------- Beam Levels ----------------------------
static uint8_t        LOWBEAM_LEVEL  = 40;                    // User-adjustable low beam maximum brightness
static const uint8_t  HIGHBEAM_LEVEL = 255;                   // High beam always operates at full intensity

// ---------------------- 3-position Switch ----------------------
static const uint8_t  SW_PIN_I  = 22;                         // Switch contact for position I (low beam)
static const uint8_t  SW_PIN_II = 23;                         // Switch contact for position II (low + high beam)
static const uint32_t SWITCH_DEBOUNCE_MS = 25;                // Debounce time to reject switch bounce

// ---------------------- Ring Mapping ---------------------------
static const uint16_t RING_LED_COUNT[9] = {60, 48, 40, 32, 24, 16, 12, 8, 1};  // LED count per ring
static const uint16_t RING_START_IDX[9] = {0, 60, 108, 148, 180, 204, 220, 232, 240}; // First LED index per ring

static const bool LOWBEAM_RING_ENABLE[9] = {                  // Rings used for low beam rendering
  true, true, true, true, false, false, false, false, false
};

static const bool HIGHBEAM_RING_ENABLE[9] = {                 // Rings used for high beam overlay
  false, false, false, false, false, true, true, true, true
};

// ---------------------- Geometry -------------------------------
static const float START_ANGLE_DEG = 90.0f;                   // Angular offset of the first LED in each ring
static const float RING_RADIUS[9]  = {85, 75, 65, 55, 45, 35, 25, 15, 5}; // Radius of each ring in arbitrary display units

// ---------------------- Beam Model -----------------------------
static const float CUT_Y0_NORM               = 0.030f;        // Base vertical cut-off offset in normalized units
static const float PITCH_SHIFT_PER_DEG_NORM  = 0.0174533f;    // Vertical cut-off shift per degree of pitch
static const float SOFT_BAND_NORM            = 0.03f;         // Width of the transition band around the cut-off
static const float EDGE_GAMMA                = 3.8f;          // Nonlinear shaping of brightness transition
static const bool  ONE_SIDED_CUTOFF          = false;         // false = symmetric transition around cut-off

static const uint8_t LB_R = 255;                              // Low beam red component
static const uint8_t LB_G = 255;                              // Low beam green component
static const uint8_t LB_B = 255;                              // Low beam blue component

static const float ROLL_LED_SIGN  = +1.0f;                    // Optional sign inversion for roll in the LED domain
static const float PITCH_LED_SIGN = +1.0f;                    // Optional sign inversion for pitch in the LED domain

// ---------------------- LED Output Smoothing -------------------
static const float ROLL_LPF_ALPHA  = 0.05f;                   // Low-pass filter factor for displayed roll angle
static const float PITCH_LPF_ALPHA = 0.45f;                   // Low-pass filter factor for displayed pitch angle

static const float ROLL_DEADBAND_DEG  = 0.03f;                // Ignore very small roll changes to avoid jitter
static const float PITCH_DEADBAND_DEG = 0.12f;                // Ignore very small pitch changes to avoid jitter

// ---------------------- IMU ------------------------------------
BoschSensorClass imu(Wire1);                                  // IMU instance on secondary I2C bus used by the display shield

// Prototype axis interpretation:
// X = Up/Down
// Y = Right/Left
// Z = Forward
static const AxisSel MAP_PROT_X = AXIS_X;                     // Map prototype X to sensor X
static const AxisSel MAP_PROT_Y = AXIS_Y;                     // Map prototype Y to sensor Y
static const AxisSel MAP_PROT_Z = AXIS_Z;                     // Map prototype Z to sensor Z

static const int8_t SIGN_PROT_X = +1;                         // Sign correction for prototype X
static const int8_t SIGN_PROT_Y = -1;                         // Sign correction for prototype Y
static const int8_t SIGN_PROT_Z = -1;                         // Sign correction for prototype Z

// ---------------------- Timing ---------------------------------
static const uint32_t IMU_UPDATE_US = 5000;                   // Target IMU service interval (~200 Hz)
static const uint32_t LED_UPDATE_MS = 10;                     // LED update interval (~100 Hz)

static const float DT_MIN_S = 0.001f;                         // Minimum dt clamp for numerical robustness
static const float DT_MAX_S = 0.020f;                         // Maximum dt clamp for numerical robustness

// ---------------------- Complementary Filter -------------------
static float COMP_ALPHA_ROLL  = 0.87f;                        // Base roll complementary filter alpha
static float COMP_ALPHA_PITCH = 0.99f;                        // Base pitch complementary filter alpha

static const float COMP_ACC_TRUST_GAIN_ROLL  = 1.6f;          // Roll accelerometer trust falloff gain
static const float COMP_ACC_TRUST_GAIN_PITCH = 2.6f;          // Pitch accelerometer trust falloff gain

static const float ROLL_LIMIT_DEG  = 60.0f;                   // Clamp output roll angle to a safe display range
static const float PITCH_LIMIT_DEG = 40.0f;                   // Clamp output pitch angle to a safe display range

static const uint32_t GYRO_BIAS_MS = 1000;                    // Duration of gyro bias calibration

// ---------------------- Madgwick Filter ------------------------
static float MADGWICK_BETA = 0.25f;                           // Base Madgwick beta gain
static const float MADGWICK_ACC_TRUST_GAIN = 1.2f;            // Trust reduction gain used for adaptive beta
static const float MADGWICK_BETA_MIN_FACTOR = 0.35f;          // Minimum beta scaling factor
static float madgwickBetaEff = 0.25f;                         // Effective beta after adaptive weighting

// ---------------------- Debug ----------------------------------
static const uint32_t DEBUG_PRINT_MS = 500;                   // Period for optional serial debug output

// ---------------------- Display UI -----------------------------
static const uint32_t DISPLAY_UPDATE_MS = 120;                // UI refresh period independent of control loop
static const float DISPLAY_PITCH_PX_PER_DEG = 4.5f;           // Conversion from pitch angle to horizon vertical shift in pixels

/* =========================================================
   END USER CONFIGURATION
   ========================================================= */

Adafruit_NeoPixel strip(NUM_LEDS, DATA_PIN, NEO_GRB + NEO_KHZ800); // LED strip object configured for WS2812 timing
Arduino_H7_Video Display(800, 480, GigaDisplayShield);              // Display video backend object
GigaDisplay_GFX gfx;                                                // Graphics abstraction used for UI drawing

/* =========================================================
   LED MAP STORAGE
   ========================================================= */
struct LedXY {
  uint16_t idx;                                              // Physical LED index in the strip
  float x;                                                   // LED x-coordinate in beam model space
  float y;                                                   // LED y-coordinate in beam model space
};

static LedXY ledMap[180];                                    // Storage for low-beam LEDs only (rings 0..3)
static uint16_t ledMapCount = 0;                             // Actual number of valid entries in ledMap

/* =========================================================
   HELPER FUNCTIONS
   ========================================================= */
static inline float pickAxis(AxisSel s, float x, float y, float z) {
  return (s == AXIS_X) ? x : (s == AXIS_Y) ? y : z;          // Return the selected axis component
}

static inline float clamp01(float v) {
  if (v < 0.0f) return 0.0f;                                 // Clamp lower bound to 0
  if (v > 1.0f) return 1.0f;                                 // Clamp upper bound to 1
  return v;                                                  // Otherwise keep input unchanged
}

static inline float clampf(float v, float lo, float hi) {
  if (v < lo) return lo;                                     // Clamp to lower limit
  if (v > hi) return hi;                                     // Clamp to upper limit
  return v;                                                  // Otherwise keep input unchanged
}

static inline uint32_t rgbScaledLowBeam(float a) {
  a = clamp01(a);                                            // Keep brightness coefficient inside 0..1
  float level = (float)LOWBEAM_LEVEL / 255.0f;               // Convert user brightness level into a normalized factor
  return strip.Color(                                        // Return packed RGB color for low beam
    (uint8_t)(LB_R * a * level),
    (uint8_t)(LB_G * a * level),
    (uint8_t)(LB_B * a * level)
  );
}

static inline uint32_t rgbHighBeam() {
  float level = (float)HIGHBEAM_LEVEL / 255.0f;              // Convert high beam level into a normalized factor
  return strip.Color(                                        // Return packed RGB color for high beam
    (uint8_t)(LB_R * level),
    (uint8_t)(LB_G * level),
    (uint8_t)(LB_B * level)
  );
}

float computeAccTrust(float ax, float ay, float az, float gain) {
  float aNorm = sqrtf(ax * ax + ay * ay + az * az);          // Compute acceleration vector magnitude in g
  float trust = 1.0f - gain * fabsf(aNorm - 1.0f);           // Reduce trust as measured magnitude moves away from 1 g
  return clamp01(trust);                                     // Limit trust to the interval 0..1
}

/* =========================================================
   SWITCH / BEAM MODE
   ========================================================= */
SwitchState readSwitchRaw() {
  bool iLow  = (digitalRead(SW_PIN_I)  == LOW);              // Read position I contact (active low)
  bool iiLow = (digitalRead(SW_PIN_II) == LOW);              // Read position II contact (active low)

  if (iLow && !iiLow)  return SW_I;                          // Only position I active
  if (iiLow && !iLow)  return SW_II;                         // Only position II active
  return SW_OFF;                                             // Default to OFF if neither or both are active
}

SwitchState readSwitchDebounced() {
  static SwitchState lastStable = SW_OFF;                    // Most recent debounced switch state
  static SwitchState lastRaw = SW_OFF;                       // Most recent raw switch state
  static uint32_t tChange = 0;                               // Time stamp of last raw state change

  SwitchState raw = readSwitchRaw();                         // Read current raw switch state

  if (raw != lastRaw) {                                      // Detect any transition in the raw input
    lastRaw = raw;                                           // Store the new raw state
    tChange = millis();                                      // Reset debounce timer
  }

  if (millis() - tChange > SWITCH_DEBOUNCE_MS) {             // Accept state only after debounce interval elapsed
    lastStable = raw;                                        // Promote raw state to debounced state
  }

  return lastStable;                                         // Return stable debounced state
}

BeamMode beamModeFromSwitch(SwitchState s) {
  if (s == SW_OFF) return BEAM_ALL_OFF;                      // OFF position -> all lights off
  if (s == SW_I)   return BEAM_LOW_ONLY;                     // Position I -> low beam only
  return BEAM_LOW_AND_HIGH;                                  // Position II -> low + high beam
}

/* =========================================================
   BEAM MATH
   ========================================================= */
float brightnessFromCutoff(float yWorld, float yCut, float band) {
  if (ONE_SIDED_CUTOFF) {                                    // Use one-sided transition if enabled
    if (yWorld >= yCut) return 0.0f;                         // LEDs above cut-off are fully off

    float d = yCut - yWorld;                                 // Distance below cut-off
    if (d >= band) return 1.0f;                              // LEDs far enough below cut-off are fully on

    float a = d / band;                                      // Normalize distance inside transition band
    return powf(a, EDGE_GAMMA);                              // Apply gamma shaping to transition
  } else {                                                   // Use symmetric soft transition around cut-off
    float d = yCut - yWorld;                                 // Signed distance from cut-off line

    if (d <= -band) return 0.0f;                             // Well above cut-off -> off
    if (d >=  band) return 1.0f;                             // Well below cut-off -> on

    float a = (d + band) / (2.0f * band);                    // Map distance into 0..1 transition interval
    return powf(a, EDGE_GAMMA);                              // Apply gamma shaping to transition
  }
}

/* =========================================================
   BUILD LED MAP
   ========================================================= */
void buildLedMap() {
  ledMapCount = 0;                                           // Reset map entry counter
  const float startRad = START_ANGLE_DEG * (3.1415926f / 180.0f); // Convert configured start angle to radians

  for (uint8_t r = 0; r < 9; r++) {                          // Iterate through all rings
    if (!LOWBEAM_RING_ENABLE[r]) continue;                   // Skip rings not used for low beam

    const uint16_t n    = RING_LED_COUNT[r];                 // Number of LEDs in the current ring
    const uint16_t base = RING_START_IDX[r];                 // Starting strip index for the current ring
    const float    rad  = RING_RADIUS[r];                    // Radius of current ring in model coordinates

    for (uint16_t k = 0; k < n; k++) {                       // Build one map entry for each LED in the ring
      float ang = startRad - (2.0f * 3.1415926f * (float)k / (float)n); // Angular position, clockwise direction
      ledMap[ledMapCount++] = {                              // Store strip index and 2D beam-model coordinates
        (uint16_t)(base + k),
        rad * cosf(ang),
        rad * sinf(ang)
      };
    }
  }
}

/* =========================================================
   IMU + FILTER STATE
   ========================================================= */
static ImuMode imuMode = MODE_COMP;                          // Default estimator mode

float aX, aY, aZ;                                            // Accelerometer in prototype frame (g)
float gX, gY, gZ;                                            // Gyroscope in prototype frame (deg/s), bias corrected

float biasGX = 0, biasGY = 0, biasGZ = 0;                    // Estimated gyro offsets
bool  gyroBiasValid = false;                                 // Indicates whether bias calibration has been performed

float rollAcc = 0, pitchAcc = 0;                             // Angles derived directly from accelerometer
float rollDeg = 0, pitchDeg = 0;                             // Final filtered output angles
float rollZero = 0, pitchZero = 0;                           // User-defined zero offsets

float rollLED = 0, pitchLED = 0;                             // Smoothed angles actually used for LED rendering

uint32_t lastImuUs = 0;                                      // Timestamp of last IMU update
uint32_t lastLedMs = 0;                                      // Timestamp of last LED update
uint32_t lastDebugMs = 0;                                    // Timestamp of last optional debug update
uint32_t lastDisplayMs = 0;                                  // Timestamp of last display update

float imuDt = 0.005f;                                        // Most recent measured IMU delta time

// Display state
float lastRollDispDrawn  = 9999.0f;                          // Last displayed roll value
float lastPitchDispDrawn = 9999.0f;                          // Last displayed pitch value
BeamMode lastBeamModeDrawn = BEAM_ALL_OFF;                   // Last displayed beam mode

int prevHx0 = 0, prevHy0 = 0, prevHx1 = 0, prevHy1 = 0;      // Previous horizon line endpoints for efficient redraw
bool prevHorizonValid = false;                               // Indicates whether previous horizon line is valid

// Madgwick quaternion state
float q0 = 1.0f, q1 = 0.0f, q2 = 0.0f, q3 = 0.0f;            // Orientation quaternion state

/* =========================================================
   AXIS MAPPING
   ========================================================= */
void mapToPrototype(float ax, float ay, float az, float gx, float gy, float gz) {
  aX = SIGN_PROT_X * pickAxis(MAP_PROT_X, ax, ay, az);       // Map and sign-correct accelerometer X
  aY = SIGN_PROT_Y * pickAxis(MAP_PROT_Y, ax, ay, az);       // Map and sign-correct accelerometer Y
  aZ = SIGN_PROT_Z * pickAxis(MAP_PROT_Z, ax, ay, az);       // Map and sign-correct accelerometer Z

  gX = SIGN_PROT_X * pickAxis(MAP_PROT_X, gx, gy, gz) - biasGX; // Map, sign-correct and bias-correct gyroscope X
  gY = SIGN_PROT_Y * pickAxis(MAP_PROT_Y, gx, gy, gz) - biasGY; // Map, sign-correct and bias-correct gyroscope Y
  gZ = SIGN_PROT_Z * pickAxis(MAP_PROT_Z, gx, gy, gz) - biasGZ; // Map, sign-correct and bias-correct gyroscope Z
}

/* =========================================================
   ACCELEROMETER ANGLES
   ========================================================= */
void computeAccelAngles() {
  rollAcc  = atan2f(aY, aX) * 180.0f / 3.1415926f;           // Estimate roll from accelerometer geometry
  pitchAcc = atan2f(aZ, aX) * 180.0f / 3.1415926f;           // Estimate pitch from accelerometer geometry
}

/* =========================================================
   GYRO BIAS CALIBRATION
   ========================================================= */
void calibrateGyroBias() {
  Serial.println("\n[CAL] Gyro bias: keep prototype still...");   // Prompt user to hold system stationary

  uint32_t t0 = millis();                                         // Start calibration timer
  uint32_t n = 0;                                                 // Sample counter
  float sx = 0, sy = 0, sz = 0;                                   // Running sums for gyro bias estimation

  while (millis() - t0 < GYRO_BIAS_MS) {                         // Collect samples during calibration window
    float gx, gy, gz;                                            // Temporary raw gyro readings
    imu.readGyroscope(gx, gy, gz);                               // Read gyroscope from sensor

    float tmpX = SIGN_PROT_X * pickAxis(MAP_PROT_X, gx, gy, gz); // Map and sign-correct X
    float tmpY = SIGN_PROT_Y * pickAxis(MAP_PROT_Y, gx, gy, gz); // Map and sign-correct Y
    float tmpZ = SIGN_PROT_Z * pickAxis(MAP_PROT_Z, gx, gy, gz); // Map and sign-correct Z

    sx += tmpX;                                                  // Accumulate X samples
    sy += tmpY;                                                  // Accumulate Y samples
    sz += tmpZ;                                                  // Accumulate Z samples
    n++;                                                         // Count sample

    delay(5);                                                    // Slow loop slightly during calibration
  }

  if (n == 0) return;                                            // Abort if no samples were collected

  biasGX = sx / (float)n;                                        // Compute average X gyro bias
  biasGY = sy / (float)n;                                        // Compute average Y gyro bias
  biasGZ = sz / (float)n;                                        // Compute average Z gyro bias
  gyroBiasValid = true;                                          // Mark bias as valid

  Serial.print("[CAL] biasGX / biasGY / biasGZ = ");            // Print calibration result for verification
  Serial.print(biasGX, 3); Serial.print(" / ");
  Serial.print(biasGY, 3); Serial.print(" / ");
  Serial.println(biasGZ, 3);
}

/* =========================================================
   ZERO FUNCTION
   ========================================================= */
void setZeroHere() {
  rollZero  = rollDeg;                                       // Store current roll as new zero reference
  pitchZero = pitchDeg;                                      // Store current pitch as new zero reference
  Serial.println("[INFO] Zero set: current roll/pitch becomes 0/0."); // Confirm zeroing action
}

/* =========================================================
   MADGWICK SUPPORT
   ========================================================= */
void madgwickUpdateIMU(float gx_rad, float gy_rad, float gz_rad,
                       float ax, float ay, float az,
                       float dt, float betaUse) {
  float norm = sqrtf(ax * ax + ay * ay + az * az);           // Compute accelerometer magnitude
  if (norm < 1e-6f) return;                                  // Reject invalid accelerometer vectors

  ax /= norm;                                                // Normalize accelerometer X
  ay /= norm;                                                // Normalize accelerometer Y
  az /= norm;                                                // Normalize accelerometer Z

  float _2q0 = 2.0f * q0;                                    // Precompute repeated quaternion terms
  float _2q1 = 2.0f * q1;
  float _2q2 = 2.0f * q2;
  float _2q3 = 2.0f * q3;
  float _4q0 = 4.0f * q0;
  float _4q1 = 4.0f * q1;
  float _4q2 = 4.0f * q2;
  float _8q1 = 8.0f * q1;
  float _8q2 = 8.0f * q2;
  float q0q0 = q0 * q0;                                      // Precompute quaternion products
  float q1q1 = q1 * q1;
  float q2q2 = q2 * q2;
  float q3q3 = q3 * q3;

  float s0 = _4q0 * q2q2 + _2q2 * ax + _4q0 * q1q1 - _2q1 * ay; // Gradient descent step component 0
  float s1 = _4q1 * q3q3 - _2q3 * ax + 4.0f * q0q0 * q1 - _2q0 * ay - _4q1 + _8q1 * q1q1 + _8q1 * q2q2 + _4q1 * az; // Step component 1
  float s2 = 4.0f * q0q0 * q2 + _2q0 * ax + _4q2 * q3q3 - _2q3 * ay - _4q2 + _8q2 * q1q1 + _8q2 * q2q2 + _4q2 * az; // Step component 2
  float s3 = 4.0f * q1q1 * q3 - _2q1 * ax + 4.0f * q2q2 * q3 - _2q2 * ay; // Step component 3

  norm = sqrtf(s0 * s0 + s1 * s1 + s2 * s2 + s3 * s3);      // Compute step vector norm
  if (norm < 1e-9f) return;                                  // Reject degenerate correction step

  s0 /= norm;                                                // Normalize step vector component 0
  s1 /= norm;                                                // Normalize step vector component 1
  s2 /= norm;                                                // Normalize step vector component 2
  s3 /= norm;                                                // Normalize step vector component 3

  float qDot0 = 0.5f * (-q1 * gx_rad - q2 * gy_rad - q3 * gz_rad) - betaUse * s0; // Quaternion derivative 0
  float qDot1 = 0.5f * ( q0 * gx_rad + q2 * gz_rad - q3 * gy_rad) - betaUse * s1;  // Quaternion derivative 1
  float qDot2 = 0.5f * ( q0 * gy_rad - q1 * gz_rad + q3 * gx_rad) - betaUse * s2;  // Quaternion derivative 2
  float qDot3 = 0.5f * ( q0 * gz_rad + q1 * gy_rad - q2 * gx_rad) - betaUse * s3;  // Quaternion derivative 3

  q0 += qDot0 * dt;                                          // Integrate quaternion component 0
  q1 += qDot1 * dt;                                          // Integrate quaternion component 1
  q2 += qDot2 * dt;                                          // Integrate quaternion component 2
  q3 += qDot3 * dt;                                          // Integrate quaternion component 3

  norm = sqrtf(q0 * q0 + q1 * q1 + q2 * q2 + q3 * q3);      // Compute quaternion norm after integration
  if (norm < 1e-9f) return;                                  // Reject invalid quaternion norm

  q0 /= norm;                                                // Normalize quaternion component 0
  q1 /= norm;                                                // Normalize quaternion component 1
  q2 /= norm;                                                // Normalize quaternion component 2
  q3 /= norm;                                                // Normalize quaternion component 3
}

void madgwickGetRollPitchDeg(float &rollOut, float &pitchOut) {
  float sinr_cosp = 2.0f * (q0 * q1 + q2 * q3);              // Numerator term for roll extraction
  float cosr_cosp = 1.0f - 2.0f * (q1 * q1 + q2 * q2);       // Denominator term for roll extraction
  float roll = atan2f(sinr_cosp, cosr_cosp);                 // Compute roll in radians from quaternion

  float sinp = 2.0f * (q0 * q2 - q3 * q1);                   // Argument used for pitch extraction
  sinp = clampf(sinp, -1.0f, 1.0f);                          // Clamp to avoid invalid asinf input
  float pitch = asinf(sinp);                                 // Compute pitch in radians from quaternion

  rollOut  = roll  * 180.0f / 3.1415926f;                    // Convert roll to degrees
  pitchOut = pitch * 180.0f / 3.1415926f;                    // Convert pitch to degrees
}

void resetMadgwickToAccel() {
  q0 = 1.0f;                                                 // Reset quaternion to identity orientation
  q1 = 0.0f;                                                 // Reset quaternion x component
  q2 = 0.0f;                                                 // Reset quaternion y component
  q3 = 0.0f;                                                 // Reset quaternion z component
}

/* =========================================================
   MAIN IMU SERVICE
   ========================================================= */
void imuService() {
  uint32_t now = micros();                                   // Current microsecond timestamp
  uint32_t dtUs = now - lastImuUs;                           // Elapsed time since previous IMU update

  if (dtUs < IMU_UPDATE_US) return;                          // Enforce target IMU update period

  lastImuUs = now;                                           // Store current timestamp as last IMU update

  imuDt = (float)dtUs * 1e-6f;                               // Convert dt from microseconds to seconds
  imuDt = clampf(imuDt, DT_MIN_S, DT_MAX_S);                 // Clamp dt to avoid extreme numerical values

  float ax, ay, az, gx, gy, gz;                              // Temporary raw sensor variables
  imu.readAcceleration(ax, ay, az);                          // Read raw accelerometer values
  imu.readGyroscope(gx, gy, gz);                             // Read raw gyroscope values

  mapToPrototype(ax, ay, az, gx, gy, gz);                    // Transform raw data into prototype coordinate frame
  computeAccelAngles();                                      // Compute roll/pitch estimates from accelerometer only

  if (imuMode == MODE_ACC_ONLY) {                            // Simple accelerometer-only operating mode
    rollDeg  = clampf(rollAcc,  -ROLL_LIMIT_DEG,  ROLL_LIMIT_DEG);   // Clamp roll output
    pitchDeg = clampf(pitchAcc, -PITCH_LIMIT_DEG, PITCH_LIMIT_DEG);  // Clamp pitch output
    madgwickBetaEff = 0.0f;                                  // Clear displayed Madgwick beta when not used
    return;                                                  // Exit after ACC-only update
  }

  if (imuMode == MODE_COMP) {                                // Complementary filter operating mode
    float trustRoll  = computeAccTrust(aX, aY, aZ, COMP_ACC_TRUST_GAIN_ROLL);   // Estimate roll accelerometer trust
    float trustPitch = computeAccTrust(aX, aY, aZ, COMP_ACC_TRUST_GAIN_PITCH);  // Estimate pitch accelerometer trust

    float alphaRollEff  = 1.0f - (1.0f - COMP_ALPHA_ROLL)  * trustRoll;   // Adaptive effective alpha for roll
    float alphaPitchEff = 1.0f - (1.0f - COMP_ALPHA_PITCH) * trustPitch;  // Adaptive effective alpha for pitch

    rollDeg  += gZ * imuDt;                                  // Integrate roll using gyro Z rate
    pitchDeg += gY * imuDt;                                  // Integrate pitch using gyro Y rate

    rollDeg  = alphaRollEff  * rollDeg  + (1.0f - alphaRollEff)  * rollAcc;   // Fuse roll gyro + accelerometer
    pitchDeg = alphaPitchEff * pitchDeg + (1.0f - alphaPitchEff) * pitchAcc;  // Fuse pitch gyro + accelerometer

    rollDeg  = clampf(rollDeg,  -ROLL_LIMIT_DEG,  ROLL_LIMIT_DEG);   // Clamp final roll output
    pitchDeg = clampf(pitchDeg, -PITCH_LIMIT_DEG, PITCH_LIMIT_DEG);  // Clamp final pitch output

    madgwickBetaEff = 0.0f;                                  // Clear displayed Madgwick beta when not used
    return;                                                  // Exit after complementary filter update
  }

  float ax_s = aZ;                                           // Map prototype acceleration into Madgwick internal frame X
  float ay_s = aY;                                           // Map prototype acceleration into Madgwick internal frame Y
  float az_s = aX;                                           // Map prototype acceleration into Madgwick internal frame Z

  const float DEG2RAD = 3.1415926f / 180.0f;                 // Constant for degree-to-radian conversion
  float gx_s = gZ * DEG2RAD;                                 // Map prototype gyro into Madgwick internal frame X
  float gy_s = gY * DEG2RAD;                                 // Map prototype gyro into Madgwick internal frame Y
  float gz_s = gX * DEG2RAD;                                 // Map prototype gyro into Madgwick internal frame Z

  float accTrust = computeAccTrust(ax_s, ay_s, az_s, MADGWICK_ACC_TRUST_GAIN); // Estimate accelerometer trust for Madgwick
  float betaFactor = MADGWICK_BETA_MIN_FACTOR +              // Compute adaptive beta scaling
                     (1.0f - MADGWICK_BETA_MIN_FACTOR) * accTrust;

  madgwickBetaEff = MADGWICK_BETA * betaFactor;              // Store effective beta for debug display

  madgwickUpdateIMU(gx_s, gy_s, gz_s, ax_s, ay_s, az_s, imuDt, madgwickBetaEff); // Update quaternion state
  madgwickGetRollPitchDeg(rollDeg, pitchDeg);                // Convert quaternion into roll/pitch degrees

  rollDeg  = clampf(rollDeg,  -ROLL_LIMIT_DEG,  ROLL_LIMIT_DEG);   // Clamp final roll output
  pitchDeg = clampf(pitchDeg, -PITCH_LIMIT_DEG, PITCH_LIMIT_DEG);  // Clamp final pitch output
}

/* =========================================================
   LED RENDERING
   ========================================================= */
void renderLowBeamNoShow(float rollInDeg, float pitchInDeg) {
  strip.clear();                                             // Clear previous LED frame before re-rendering low beam

  const float outerR = RING_RADIUS[0];                       // Use outermost ring radius as normalization reference
  const float band   = SOFT_BAND_NORM * outerR;              // Compute cut-off transition width in model units
  const float yCut   = (CUT_Y0_NORM + (pitchInDeg * PITCH_SHIFT_PER_DEG_NORM)) * outerR; // Compute pitch-shifted cut-off position

  const float rollRad = rollInDeg * (3.1415926f / 180.0f);   // Convert input roll angle to radians
  const float c = cosf(rollRad);                             // Precompute cosine of roll angle
  const float s = sinf(rollRad);                             // Precompute sine of roll angle

  for (uint16_t i = 0; i < ledMapCount; i++) {               // Iterate over all low-beam LEDs
    float x = ledMap[i].x;                                   // Original LED x-coordinate in model space
    float y = ledMap[i].y;                                   // Original LED y-coordinate in model space

    float xW = x * c - y * s;                                // Rotate LED x-coordinate by roll angle
    float yW = x * s + y * c;                                // Rotate LED y-coordinate by roll angle

    float a = brightnessFromCutoff(yW, yCut, band);          // Compute brightness factor relative to cut-off line
    if (a > 0.0f) {                                          // Skip LEDs that should remain fully off
      strip.setPixelColor(ledMap[i].idx, rgbScaledLowBeam(a)); // Apply scaled low-beam color to LED
    }
  }
}

void applyHighBeamOverlay() {
  uint32_t col = rgbHighBeam();                              // Compute packed color for high beam overlay

  for (uint8_t r = 0; r < 9; r++) {                          // Iterate over all rings
    if (!HIGHBEAM_RING_ENABLE[r]) continue;                  // Skip rings not assigned to high beam

    uint16_t base = RING_START_IDX[r];                       // First LED index of the current ring
    uint16_t n    = RING_LED_COUNT[r];                       // LED count in the current ring

    for (uint16_t k = 0; k < n; k++) {                       // Iterate over all LEDs in the current ring
      strip.setPixelColor(base + k, col);                    // Set full-intensity high beam color on each LED
    }
  }
}

/* =========================================================
   SERIAL COMMANDS
   ========================================================= */
String readLine() {
  String s = Serial.readStringUntil('\n');                   // Read input from serial monitor until newline
  s.trim();                                                  // Remove leading/trailing whitespace
  return s;                                                  // Return cleaned command string
}

const char* imuModeName() {
  if (imuMode == MODE_ACC_ONLY) return "ACC_ONLY";          // Human-readable name for accelerometer-only mode
  if (imuMode == MODE_COMP)     return "COMP";              // Human-readable name for complementary filter mode
  return "MADGWICK";                                        // Human-readable name for Madgwick mode
}

void printHelp() {
  Serial.println("\nCommands:");                           // Print command menu header
  Serial.println("  h            -> help");                // Help command description
  Serial.println("  z            -> zero current position"); // Zero command description
  Serial.println("  s            -> print roll / pitch once"); // Status command description
  Serial.println("  b <0-255>    -> set LOW BEAM brightness only"); // Brightness command description
  Serial.println("  c            -> calibrate gyro bias"); // Calibration command description
  Serial.println("  m a          -> ACC_ONLY mode");       // IMU mode command for ACC_ONLY
  Serial.println("  m f          -> COMP mode (default)"); // IMU mode command for COMP
  Serial.println("  m g          -> MADGWICK mode");       // IMU mode command for MADGWICK
  Serial.println("  k <beta>     -> set Madgwick base beta"); // Madgwick beta command description
  Serial.println("  ar <value>   -> set COMP alpha roll  (0.90..0.999)"); // Roll alpha tuning command description
  Serial.println("  ap <value>   -> set COMP alpha pitch (0.90..0.999)"); // Pitch alpha tuning command description

  Serial.println("\nSwitch mode:");                       // Print switch mode section header
  Serial.println("  0  -> all LEDs OFF");                 // Switch OFF state description
  Serial.println("  I  -> LOW beam only");                // Switch position I description
  Serial.println("  II -> LOW + HIGH beam");              // Switch position II description

  Serial.print("\nCurrent IMU mode: ");                  // Print current active IMU mode label
  Serial.println(imuModeName());                             // Print current IMU mode value
}

void printStatusOnce() {
  float aNorm = sqrtf(aX * aX + aY * aY + aZ * aZ);          // Compute acceleration magnitude for diagnostic output

  Serial.print("mode: ");                                   // Print mode label
  Serial.print(imuModeName());                               // Print current IMU mode

  Serial.print(" | roll_deg: ");                            // Print roll label
  Serial.print((rollDeg - rollZero), 2);                     // Print zero-referenced roll angle

  Serial.print(" | pitch_deg: ");                           // Print pitch label
  Serial.print((pitchDeg - pitchZero), 2);                   // Print zero-referenced pitch angle

  Serial.print(" | dt_ms: ");                               // Print dt label
  Serial.print(imuDt * 1000.0f, 2);                          // Print IMU update interval in milliseconds

  Serial.print(" | |a|: ");                                 // Print acceleration magnitude label
  Serial.print(aNorm, 3);                                    // Print acceleration magnitude

  Serial.print(" | LB: ");                                  // Print low-beam brightness label
  Serial.print(LOWBEAM_LEVEL);                               // Print current low-beam brightness level

  Serial.print(" | HB: ");                                  // Print high-beam brightness label
  Serial.print(HIGHBEAM_LEVEL);                              // Print current high-beam brightness level

  if (imuMode == MODE_COMP) {                                // Print complementary filter diagnostics when active
    float trustRoll  = computeAccTrust(aX, aY, aZ, COMP_ACC_TRUST_GAIN_ROLL);   // Recompute roll trust for display
    float trustPitch = computeAccTrust(aX, aY, aZ, COMP_ACC_TRUST_GAIN_PITCH);  // Recompute pitch trust for display

    float alphaRollEff  = 1.0f - (1.0f - COMP_ALPHA_ROLL)  * trustRoll;   // Effective roll alpha for display
    float alphaPitchEff = 1.0f - (1.0f - COMP_ALPHA_PITCH) * trustPitch;  // Effective pitch alpha for display

    Serial.print(" | aR: ");                                // Print effective roll alpha label
    Serial.print(alphaRollEff, 3);                           // Print effective roll alpha value

    Serial.print(" | aP: ");                                // Print effective pitch alpha label
    Serial.print(alphaPitchEff, 3);                          // Print effective pitch alpha value
  }

  if (imuMode == MODE_MADGWICK) {                            // Print Madgwick diagnostics when active
    Serial.print(" | beta_base: ");                         // Print base beta label
    Serial.print(MADGWICK_BETA, 3);                          // Print user-configured beta value

    Serial.print(" | beta_eff: ");                          // Print effective beta label
    Serial.print(madgwickBetaEff, 3);                        // Print adaptive effective beta value
  }

  Serial.println();                                          // Terminate diagnostic line
}

void handleSerial() {
  if (!Serial.available()) return;                           // Return immediately if no serial input is waiting

  String cmd = readLine();                                   // Read full command line from serial interface
  if (cmd.length() == 0) return;                             // Ignore empty commands

  if (cmd == "h") {                                          // Help command
    printHelp();                                             // Print command menu
  }
  else if (cmd == "z") {                                     // Zero command
    setZeroHere();                                           // Store current orientation as zero reference
  }
  else if (cmd == "s") {                                     // Status command
    printStatusOnce();                                       // Print one line of status information
  }
  else if (cmd.startsWith("b")) {                            // Brightness command
    int val = cmd.substring(1).toInt();                      // Parse user-supplied brightness value
    if (val < 0) val = 0;                                    // Clamp lower bound
    if (val > 255) val = 255;                                // Clamp upper bound

    LOWBEAM_LEVEL = (uint8_t)val;                            // Update low-beam brightness setting
    Serial.print("[INFO] Low beam brightness set to ");     // Confirm new brightness value
    Serial.println(LOWBEAM_LEVEL);
    Serial.println("[INFO] High beam remains at full intensity."); // Clarify high beam behaviour
  }
  else if (cmd == "c") {                                     // Gyro calibration command
    calibrateGyroBias();                                     // Run gyro bias calibration routine
  }
  else if (cmd.startsWith("m")) {                            // IMU mode command group
    char mode = cmd.charAt(cmd.length() - 1);                // Read final mode selector character

    if (mode == 'a') {                                       // Switch to accelerometer-only mode
      imuMode = MODE_ACC_ONLY;                               // Activate ACC_ONLY mode
      rollDeg = rollAcc;                                     // Initialize roll output from accelerometer estimate
      pitchDeg = pitchAcc;                                   // Initialize pitch output from accelerometer estimate
      Serial.println("[INFO] IMU mode -> ACC_ONLY");        // Confirm mode change
    }
    else if (mode == 'f') {                                  // Switch to complementary filter mode
      imuMode = MODE_COMP;                                   // Activate COMP mode
      if (!gyroBiasValid) Serial.println("[WARN] Run 'c' for gyro bias to reduce drift."); // Warn if bias not calibrated
      rollDeg = rollAcc;                                     // Initialize roll state from accelerometer estimate
      pitchDeg = pitchAcc;                                   // Initialize pitch state from accelerometer estimate
      Serial.println("[INFO] IMU mode -> COMP");            // Confirm mode change
    }
    else if (mode == 'g') {                                  // Switch to Madgwick mode
      imuMode = MODE_MADGWICK;                               // Activate MADGWICK mode
      if (!gyroBiasValid) Serial.println("[WARN] Run 'c' for gyro bias to reduce drift."); // Warn if bias not calibrated
      resetMadgwickToAccel();                                // Reset Madgwick quaternion state
      Serial.println("[INFO] IMU mode -> MADGWICK");        // Confirm mode change
    }
    else {                                                   // Invalid mode subcommand
      Serial.println("Use: m a / m f / m g");               // Print correct mode command syntax
    }
  }
  else if (cmd.startsWith("k")) {                            // Madgwick beta tuning command
    float val = cmd.substring(1).toFloat();                  // Parse beta value from command string
    if (val > 0.0f && val < 5.0f) {                          // Accept only sensible positive beta values
      MADGWICK_BETA = val;                                   // Update base beta parameter
      Serial.print("[INFO] Madgwick base beta = ");         // Confirm new beta value
      Serial.println(MADGWICK_BETA, 4);
    } else {
      Serial.println("Use: k 0.25");                        // Print example beta command syntax
    }
  }
  else if (cmd.startsWith("ar")) {                           // Complementary roll alpha tuning command
    float val = cmd.substring(2).toFloat();                  // Parse roll alpha value
    if (val >= 0.90f && val < 0.999f) {                      // Accept valid alpha range
      COMP_ALPHA_ROLL = val;                                 // Update roll alpha parameter
      Serial.print("[INFO] COMP alpha roll = ");            // Confirm new roll alpha value
      Serial.println(COMP_ALPHA_ROLL, 4);
    } else {
      Serial.println("Use: ar 0.965");                      // Print example roll alpha syntax
    }
  }
  else if (cmd.startsWith("ap")) {                           // Complementary pitch alpha tuning command
    float val = cmd.substring(2).toFloat();                  // Parse pitch alpha value
    if (val >= 0.90f && val < 0.999f) {                      // Accept valid alpha range
      COMP_ALPHA_PITCH = val;                                // Update pitch alpha parameter
      Serial.print("[INFO] COMP alpha pitch = ");           // Confirm new pitch alpha value
      Serial.println(COMP_ALPHA_PITCH, 4);
    } else {
      Serial.println("Use: ap 0.990");                      // Print example pitch alpha syntax
    }
  }
  else {                                                     // Any unrecognized command
    Serial.println("Unknown command. Type 'h'.");           // Print fallback error message
  }
}

/* =========================================================
   DISPLAY UI (GIGA Display Shield)
   ========================================================= */
static inline uint16_t rgb565(uint8_t r, uint8_t g, uint8_t b) {
  return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);   // Convert 8-bit RGB values into RGB565 format
}

// UI colors
static const uint16_t UI_BG     = 0x0000;                    // Background color (black)
static const uint16_t UI_PANEL  = 0x18C3;                    // Panel fill color
static const uint16_t UI_FRAME  = 0x7BEF;                    // Panel/frame outline color
static const uint16_t UI_WHITE  = 0xFFFF;                    // White color for main graphics
static const uint16_t UI_CYAN   = 0x05FF;                    // Cyan highlight color
static const uint16_t UI_GREEN  = 0x07E0;                    // Green value color for small angles
static const uint16_t UI_YELLOW = 0xFFE0;                    // Yellow value color for medium angles / markers
static const uint16_t UI_ORANGE = 0xFD20;                    // Orange value color for larger angles
static const uint16_t UI_RED    = 0xF800;                    // Red value color for large angles / warnings
static const uint16_t UI_DARK   = rgb565(18, 24, 32);        // Dark banner color

// Layout
static const int DISP_W = 800;                               // Display width in pixels
static const int DISP_H = 480;                               // Display height in pixels

static const int HORIZON_CX = 220;                           // X position of horizon circle centre
static const int HORIZON_CY = 250;                           // Y position of horizon circle centre
static const int HORIZON_R  = 150;                           // Radius of horizon circle

static const int RIGHT_X = 430;                              // X coordinate of right-side status panels
static const int RIGHT_W = 340;                              // Width of right-side status panels

void drawThickLine(int x0, int y0, int x1, int y1, uint16_t color, int thickness) {
  for (int o = -thickness / 2; o <= thickness / 2; o++) {    // Draw repeated offset lines to simulate thickness
    gfx.drawLine(x0, y0 + o, x1, y1 + o, color);             // Draw one offset copy of the line
  }
}

void drawCenteredText(const String &txt, int cx, int y, int textSize, uint16_t color) {
  int w = (int)txt.length() * 6 * textSize;                  // Estimate text width using GFX fixed-width font metrics
  gfx.setTextSize(textSize);                                 // Select requested text size
  gfx.setTextColor(color);                                   // Select requested text color
  gfx.setCursor(cx - w / 2, y);                              // Position text such that it appears horizontally centered
  gfx.print(txt);                                            // Draw the text string
}

uint16_t angleColor(float v) {
  float av = fabsf(v);                                       // Use absolute angle magnitude for color selection
  if (av < 5.0f)  return UI_GREEN;                           // Small angles -> green
  if (av < 15.0f) return UI_YELLOW;                          // Moderate angles -> yellow
  if (av < 25.0f) return UI_ORANGE;                          // Larger angles -> orange
  return UI_RED;                                             // Large angles -> red
}

const char* beamModeName(BeamMode m) {
  if (m == BEAM_ALL_OFF) return "OFF";                      // Human-readable label for all-off mode
  if (m == BEAM_LOW_ONLY) return "LOW";                     // Human-readable label for low beam mode
  return "HIGH";                                            // Shortened label for low+high mode to fit header layout
}

uint16_t beamModeColor(BeamMode m) {
  if (m == BEAM_ALL_OFF) return UI_RED;                      // OFF displayed in red
  if (m == BEAM_LOW_ONLY) return UI_CYAN;                    // LOW displayed in cyan
  return UI_ORANGE;                                          // HIGH displayed in orange
}

void drawStaticDisplayUI() {
  gfx.fillScreen(UI_BG);                                     // Clear entire display background

  gfx.fillRect(0, 0, DISP_W, 54, UI_DARK);                   // Draw top banner background
  gfx.drawFastHLine(0, 54, DISP_W, UI_CYAN);                 // Draw separator line under banner

  drawCenteredText("Adaptive Motorcycle Headlight", 220, 10, 2, UI_WHITE); // Draw main title
  drawCenteredText("Live Roll / Pitch Visualisation", 220, 30, 2, UI_CYAN); // Draw subtitle

  gfx.fillRoundRect(18, 72, 405, 390, 18, UI_PANEL);         // Draw left attitude-view panel background
  gfx.drawRoundRect(18, 72, 405, 390, 18, UI_FRAME);         // Draw left attitude-view panel outline
  gfx.drawRoundRect(20, 74, 401, 386, 18, UI_FRAME);         // Draw secondary outline for visual depth

  drawCenteredText("ATTITUDE VIEW", 220, 80, 2, UI_WHITE); // Label the attitude-view panel

  gfx.fillCircle(HORIZON_CX, HORIZON_CY, HORIZON_R - 4, UI_BG); // Fill inside of horizon circle with background
  gfx.drawCircle(HORIZON_CX, HORIZON_CY, HORIZON_R, UI_WHITE);   // Draw outer horizon circle
  gfx.drawCircle(HORIZON_CX, HORIZON_CY, HORIZON_R - 1, UI_WHITE); // Draw second circle outline
  gfx.drawCircle(HORIZON_CX, HORIZON_CY, HORIZON_R - 2, UI_FRAME); // Draw subtle inner circle outline

  drawThickLine(HORIZON_CX - 55, HORIZON_CY, HORIZON_CX - 15, HORIZON_CY, UI_YELLOW, 4); // Left fixed reference marker
  drawThickLine(HORIZON_CX + 15, HORIZON_CY, HORIZON_CX + 55, HORIZON_CY, UI_YELLOW, 4); // Right fixed reference marker
  drawThickLine(HORIZON_CX, HORIZON_CY - 12, HORIZON_CX, HORIZON_CY + 12, UI_YELLOW, 4); // Center vertical reference marker

  for (int deg = -30; deg <= 30; deg += 10) {                // Draw fixed tick marks around the top of the horizon circle
    float a = deg * 3.1415926f / 180.0f - 3.1415926f / 2.0f; // Convert tick angle to radians with top-centred offset
    int r1 = HORIZON_R - 10;                                 // Outer tick radius
    int r2 = (deg % 30 == 0) ? (HORIZON_R - 28) : (HORIZON_R - 18); // Longer tick every 30 degrees
    int tx0 = HORIZON_CX + (int)(r1 * cosf(a));              // Outer tick x-coordinate
    int ty0 = HORIZON_CY + (int)(r1 * sinf(a));              // Outer tick y-coordinate
    int tx1 = HORIZON_CX + (int)(r2 * cosf(a));              // Inner tick x-coordinate
    int ty1 = HORIZON_CY + (int)(r2 * sinf(a));              // Inner tick y-coordinate
    drawThickLine(tx0, ty0, tx1, ty1, UI_WHITE, 3);          // Draw tick mark
  }

  gfx.fillRoundRect(RIGHT_X, 72,  RIGHT_W, 110, 18, UI_PANEL); // Draw roll value panel background
  gfx.drawRoundRect(RIGHT_X, 72,  RIGHT_W, 110, 18, UI_FRAME); // Draw roll value panel outline

  gfx.fillRoundRect(RIGHT_X, 192, RIGHT_W, 110, 18, UI_PANEL); // Draw pitch value panel background
  gfx.drawRoundRect(RIGHT_X, 192, RIGHT_W, 110, 18, UI_FRAME); // Draw pitch value panel outline

  gfx.fillRoundRect(RIGHT_X, 312, RIGHT_W, 70, 18, UI_PANEL);  // Draw roll response panel background
  gfx.drawRoundRect(RIGHT_X, 312, RIGHT_W, 70, 18, UI_FRAME);  // Draw roll response panel outline

  gfx.fillRoundRect(RIGHT_X, 392, RIGHT_W, 70, 18, UI_PANEL);  // Draw pitch response panel background
  gfx.drawRoundRect(RIGHT_X, 392, RIGHT_W, 70, 18, UI_FRAME);  // Draw pitch response panel outline

  drawCenteredText("ROLL",  RIGHT_X + RIGHT_W / 2, 82,  2, UI_WHITE); // Draw roll panel heading
  drawCenteredText("PITCH", RIGHT_X + RIGHT_W / 2, 202, 2, UI_WHITE); // Draw pitch panel heading

  gfx.setTextSize(2);                                        // Select text size for response labels
  gfx.setTextColor(UI_WHITE);                                // Use white for response labels
  gfx.setCursor(RIGHT_X + 20, 318);                          // Position cursor for roll response label
  gfx.print("ROLL RESPONSE");                               // Draw roll response label

  gfx.setCursor(RIGHT_X + 20, 398);                          // Position cursor for pitch response label
  gfx.print("PITCH RESPONSE");                              // Draw pitch response label

  gfx.setTextSize(2);                                        // Keep text size consistent after label drawing
}

void erasePreviousHorizonLine() {
  if (!prevHorizonValid) return;                             // Do nothing if no previous line is stored

  drawThickLine(prevHx0, prevHy0, prevHx1, prevHy1, UI_BG, 7); // Erase previous horizon line by overdrawing with background

  drawThickLine(HORIZON_CX - 55, HORIZON_CY, HORIZON_CX - 15, HORIZON_CY, UI_YELLOW, 4); // Restore left reference marker
  drawThickLine(HORIZON_CX + 15, HORIZON_CY, HORIZON_CX + 55, HORIZON_CY, UI_YELLOW, 4); // Restore right reference marker
  drawThickLine(HORIZON_CX, HORIZON_CY - 12, HORIZON_CX, HORIZON_CY + 12, UI_YELLOW, 4); // Restore vertical reference marker

  gfx.drawCircle(HORIZON_CX, HORIZON_CY, HORIZON_R, UI_WHITE);    // Restore outer circle outline
  gfx.drawCircle(HORIZON_CX, HORIZON_CY, HORIZON_R - 1, UI_WHITE); // Restore secondary circle outline
  gfx.drawCircle(HORIZON_CX, HORIZON_CY, HORIZON_R - 2, UI_FRAME); // Restore inner circle outline
}

void drawHorizonDynamic(float rollDispDeg, float pitchDispDeg) {
  erasePreviousHorizonLine();                                // Remove previously drawn horizon line before drawing a new one

  float rollRad = rollDispDeg * 3.1415926f / 180.0f;         // Convert displayed roll to radians
  float pitchPx = clampf(pitchDispDeg * DISPLAY_PITCH_PX_PER_DEG,
                         -(float)(HORIZON_R - 35), (float)(HORIZON_R - 35)); // Convert displayed pitch into vertical pixel shift

  float c = cosf(rollRad);                                   // Precompute cosine of roll angle
  float s = sinf(rollRad);                                   // Precompute sine of roll angle

  float hx = (float)(HORIZON_R + 20);                        // Use a long line to guarantee intersection with circle boundary
  float xA = -hx * c;                                        // First endpoint in circle-local coordinates
  float yA = -hx * s + pitchPx;                              // First endpoint with pitch shift
  float xB =  hx * c;                                        // Second endpoint in circle-local coordinates
  float yB =  hx * s + pitchPx;                              // Second endpoint with pitch shift

  float dx = xB - xA;                                        // Direction vector X component
  float dy = yB - yA;                                        // Direction vector Y component

  float A = dx * dx + dy * dy;                               // Quadratic coefficient A for line-circle intersection
  float B = 2.0f * (xA * dx + yA * dy);                      // Quadratic coefficient B for line-circle intersection
  float C = xA * xA + yA * yA - (float)(HORIZON_R - 3) * (float)(HORIZON_R - 3); // Quadratic coefficient C using slightly reduced radius

  float disc = B * B - 4.0f * A * C;                         // Compute discriminant of quadratic equation
  if (disc < 0.0f) {                                         // If no valid intersection exists, skip drawing
    prevHorizonValid = false;                                // Mark horizon line as invalid
    return;                                                  // Exit function
  }

  float sqrtDisc = sqrtf(disc);                              // Compute square root of discriminant
  float t1 = (-B - sqrtDisc) / (2.0f * A);                   // First intersection parameter
  float t2 = (-B + sqrtDisc) / (2.0f * A);                   // Second intersection parameter

  float x0f = xA + t1 * dx;                                  // First clipped x endpoint in local coordinates
  float y0f = yA + t1 * dy;                                  // First clipped y endpoint in local coordinates
  float x1f = xA + t2 * dx;                                  // Second clipped x endpoint in local coordinates
  float y1f = yA + t2 * dy;                                  // Second clipped y endpoint in local coordinates

  int x0 = HORIZON_CX + (int)x0f;                            // Convert first endpoint into display coordinates
  int y0 = HORIZON_CY + (int)y0f;                            // Convert first endpoint into display coordinates
  int x1 = HORIZON_CX + (int)x1f;                            // Convert second endpoint into display coordinates
  int y1 = HORIZON_CY + (int)y1f;                            // Convert second endpoint into display coordinates

  drawThickLine(x0, y0, x1, y1, UI_WHITE, 5);                // Draw clipped horizon line inside circle boundary

  prevHx0 = x0;                                              // Store first endpoint for next redraw erase cycle
  prevHy0 = y0;                                              // Store first endpoint for next redraw erase cycle
  prevHx1 = x1;                                              // Store second endpoint for next redraw erase cycle
  prevHy1 = y1;                                              // Store second endpoint for next redraw erase cycle
  prevHorizonValid = true;                                   // Mark new horizon line as valid
}

void drawAnglePanel(int x, int y, float valueDeg) {
  uint16_t col = angleColor(valueDeg);                       // Select display color according to angle magnitude

  gfx.fillRect(x + 8, y + 28, RIGHT_W - 16, 72, UI_PANEL);   // Clear dynamic region inside angle panel

  String s = (valueDeg >= 0.0f ? "+" : "") + String(valueDeg, 1) + String((char)247); // Build signed angle string with degree symbol
  drawCenteredText(s, x + RIGHT_W / 2, y + 42, 5, col);      // Draw centered angle value in panel
}

void drawBarPanel(int x, int y, float valueDeg, float limitDeg, uint16_t activeCol) {
  const int barX = x + 20;                                   // Left coordinate of bar graph area
  const int barY = y + 38;                                   // Top coordinate of bar graph area
  const int barW = RIGHT_W - 40;                             // Bar graph width
  const int barH = 16;                                       // Bar graph height
  const int cx   = barX + barW / 2;                          // Centre line position of bar graph

  gfx.fillRect(x + 8, y + 28, RIGHT_W - 16, 34, UI_PANEL);   // Clear dynamic bar region only

  gfx.drawRect(barX, barY, barW, barH, UI_WHITE);            // Draw main bar outline
  gfx.drawRect(barX - 1, barY - 1, barW + 2, barH + 2, UI_FRAME); // Draw secondary outline around bar
  gfx.drawFastVLine(cx, barY - 6, barH + 12, UI_WHITE);      // Draw central zero marker

  float v = clampf(valueDeg, -limitDeg, limitDeg);           // Limit displayed value to bar range
  int px = (int)((v / limitDeg) * (barW / 2 - 2));           // Convert value into horizontal pixel displacement

  if (px >= 0) {                                             // Positive value: fill to the right of centre
    gfx.fillRect(cx, barY + 2, px, barH - 4, activeCol);     // Draw positive fill section
  } else {                                                   // Negative value: fill to the left of centre
    gfx.fillRect(cx + px, barY + 2, -px, barH - 4, activeCol); // Draw negative fill section
  }
}

void drawStatusBar(BeamMode beamMode) {
  gfx.fillRect(490, 8, 300, 38, UI_DARK);                    // Clear dynamic status area in top banner

  gfx.setTextSize(2);                                        // Select text size for status bar
  gfx.setTextColor(UI_WHITE);                                // Use white for mode text
  gfx.setCursor(470, 18);                                    // Position mode text cursor
  gfx.print("Mode: ");                                      // Print mode label
  gfx.print(imuModeName());                                  // Print current IMU mode

  gfx.setCursor(670, 18);                                    // Position beam text cursor
  gfx.setTextColor(beamModeColor(beamMode));                 // Select beam text color depending on beam state
  gfx.print("Beam: ");                                      // Print beam label
  gfx.print(beamModeName(beamMode));                         // Print current beam mode text
}

bool displayNeedsUpdate(float rollDispDeg, float pitchDispDeg, BeamMode beamMode) {
  if (beamMode != lastBeamModeDrawn) return true;            // Redraw if beam mode changed
  if (fabsf(rollDispDeg  - lastRollDispDrawn)  >= 0.15f) return true; // Redraw if roll changed enough to be visible
  if (fabsf(pitchDispDeg - lastPitchDispDrawn) >= 0.15f) return true; // Redraw if pitch changed enough to be visible
  return false;                                              // Otherwise keep current display content
}

void updateDisplayUI(float rollDispDeg, float pitchDispDeg, BeamMode beamMode) {
  if (!displayNeedsUpdate(rollDispDeg, pitchDispDeg, beamMode)) return; // Skip UI update if nothing visible changed

  drawStatusBar(beamMode);                                   // Always refresh status bar when UI updates
  lastBeamModeDrawn = beamMode;                              // Store currently drawn beam mode

  if (fabsf(rollDispDeg - lastRollDispDrawn) >= 0.15f ||
      fabsf(pitchDispDeg - lastPitchDispDrawn) >= 0.15f) {   // Update dynamic graphics only if roll/pitch changed enough
    drawHorizonDynamic(rollDispDeg, pitchDispDeg);           // Draw updated artificial horizon line
    drawAnglePanel(RIGHT_X, 72,  rollDispDeg);               // Update roll numeric display
    drawAnglePanel(RIGHT_X, 192, pitchDispDeg);              // Update pitch numeric display
    drawBarPanel(RIGHT_X, 312, rollDispDeg,  ROLL_LIMIT_DEG,  UI_CYAN);   // Update roll response bar
    drawBarPanel(RIGHT_X, 392, pitchDispDeg, PITCH_LIMIT_DEG, UI_ORANGE); // Update pitch response bar

    lastRollDispDrawn  = rollDispDeg;                        // Store last displayed roll value
    lastPitchDispDrawn = pitchDispDeg;                       // Store last displayed pitch value
  }
}

/* =========================================================
   SETUP
   ========================================================= */
void setup() {
  Serial.begin(115200);                                      // Start serial interface for debugging and user commands
  delay(200);                                                // Short delay to stabilize serial interface after boot

  strip.begin();                                             // Initialize the NeoPixel library
  strip.setBrightness(GLOBAL_STRIP_BRIGHTNESS);              // Apply fixed global strip brightness
  strip.clear();                                             // Clear all LEDs at startup
  strip.show();                                              // Send cleared LED frame to the strip

  Display.begin();                                           // Initialize the GIGA display hardware
  gfx.begin();                                               // Initialize the graphics layer
  gfx.setRotation(1);                                        // Set display orientation to landscape mode
  drawStaticDisplayUI();                                     // Draw all static display elements once
  drawStatusBar(BEAM_ALL_OFF);                               // Initialize status bar with OFF beam state
  drawHorizonDynamic(0.0f, 0.0f);                            // Draw initial horizon line at zero attitude
  drawAnglePanel(RIGHT_X, 72, 0.0f);                         // Initialize roll numeric panel
  drawAnglePanel(RIGHT_X, 192, 0.0f);                        // Initialize pitch numeric panel
  drawBarPanel(RIGHT_X, 312, 0.0f, ROLL_LIMIT_DEG, UI_CYAN); // Initialize roll response bar
  drawBarPanel(RIGHT_X, 392, 0.0f, PITCH_LIMIT_DEG, UI_ORANGE); // Initialize pitch response bar

  pinMode(SW_PIN_I, INPUT_PULLUP);                           // Configure switch input I with internal pull-up
  pinMode(SW_PIN_II, INPUT_PULLUP);                          // Configure switch input II with internal pull-up

  Wire1.begin();                                             // Initialize secondary I2C bus used by the shield IMU
  if (!imu.begin()) {                                        // Attempt to initialize IMU on the shield
    Serial.println("BMI270 not found on Wire1! Check shield seating / board selection."); // Print fatal init error
    while (1) delay(1000);                                   // Halt execution if IMU is missing
  }

  buildLedMap();                                             // Precompute LED coordinates for low-beam rendering

  lastImuUs    = micros();                                   // Initialize IMU timing reference
  lastLedMs    = millis();                                   // Initialize LED timing reference
  lastDebugMs  = millis();                                   // Initialize debug timing reference
  lastDisplayMs = millis();                                  // Initialize display timing reference

  imuMode = MODE_COMP;                                       // Set default estimation mode to complementary filter
  resetMadgwickToAccel();                                    // Reset Madgwick state for later optional use

  Serial.println("\nMain sketch v6.1 ready.");              // Print startup banner
  Serial.println("Focus: Complementary filter + optimized display UI."); // Print startup summary
  Serial.println("Recommended startup:");                   // Print recommended startup sequence header
  Serial.println("  1) keep prototype still");              // Step 1 of startup procedure
  Serial.println("  2) run 'c'");                           // Step 2 of startup procedure
  Serial.println("  3) mount prototype");                   // Step 3 of startup procedure
  Serial.println("  4) run 'z'");                           // Step 4 of startup procedure
  Serial.println("Type 'h' for help.");                     // Reminder for help command
}

/* =========================================================
   MAIN LOOP
   ========================================================= */
void loop() {
  imuService();                                              // Update IMU state and estimator outputs at configured rate
  handleSerial();                                            // Process user commands from serial monitor

  BeamMode beamMode = beamModeFromSwitch(readSwitchDebounced()); // Read current beam mode from debounced switch input
  uint32_t nowMs = millis();                                 // Get current time in milliseconds for task scheduling

  if (nowMs - lastLedMs >= LED_UPDATE_MS) {                  // Run LED rendering task at configured interval
    lastLedMs = nowMs;                                       // Store current LED update timestamp

    static BeamMode lastBeamMode = BEAM_ALL_OFF;             // Remember previously rendered beam mode

    if (beamMode == BEAM_ALL_OFF) {                          // Special case: all lights off
      if (lastBeamMode != BEAM_ALL_OFF) {                    // Only update LEDs if state actually changed to OFF
        strip.clear();                                       // Clear all LEDs
        strip.show();                                        // Push cleared frame to hardware
      }
      lastBeamMode = beamMode;                               // Store current beam mode
      return;                                                // Skip remaining loop body in OFF state
    }

    float rollTarget  = ROLL_LED_SIGN  * (rollDeg  - rollZero);  // Compute zero-referenced roll target for LED model
    float pitchTarget = PITCH_LED_SIGN * (pitchDeg - pitchZero); // Compute zero-referenced pitch target for LED model

    if (fabsf(rollTarget - rollLED) < ROLL_DEADBAND_DEG) {   // Suppress tiny roll changes below deadband
      rollTarget = rollLED;                                  // Hold previous roll display value
    }
    if (fabsf(pitchTarget - pitchLED) < PITCH_DEADBAND_DEG) {// Suppress tiny pitch changes below deadband
      pitchTarget = pitchLED;                                // Hold previous pitch display value
    }

    rollLED  = ROLL_LPF_ALPHA  * rollLED  + (1.0f - ROLL_LPF_ALPHA)  * rollTarget;  // Low-pass filter roll for LED rendering
    pitchLED = PITCH_LPF_ALPHA * pitchLED + (1.0f - PITCH_LPF_ALPHA) * pitchTarget; // Low-pass filter pitch for LED rendering

    renderLowBeamNoShow(rollLED, pitchLED);                  // Render low beam into LED frame buffer

    if (beamMode == BEAM_LOW_AND_HIGH) {                     // Add high beam only when active
      applyHighBeamOverlay();                                // Overlay high beam rings at full intensity
    }

    strip.show();                                            // Send final LED frame to hardware
    lastBeamMode = beamMode;                                 // Store current beam mode for next cycle
  }

  if (nowMs - lastDisplayMs >= DISPLAY_UPDATE_MS) {          // Run display update task at configured interval
    lastDisplayMs = nowMs;                                   // Store current display update timestamp

    float rollDisp  = rollLED;                               // Use LED-smoothed roll for visual consistency
    float pitchDisp = pitchLED;                              // Use LED-smoothed pitch for visual consistency

    updateDisplayUI(rollDisp, pitchDisp, beamMode);          // Refresh UI if display values changed enough
  }

  if (nowMs - lastDebugMs >= DEBUG_PRINT_MS) {               // Optional debug task block
    lastDebugMs = nowMs;                                     // Store current debug timestamp
    // printStatusOnce();                                    // Disabled by default to reduce serial traffic
  }
}
